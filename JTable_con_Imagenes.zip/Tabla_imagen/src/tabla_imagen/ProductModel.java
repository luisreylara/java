/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tabla_imagen;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luisr
 */
public class ProductModel {
    
    public List <Product> findAll(){
        List<Product> products = new ArrayList<Product>();
        products.add(new Product("elena", "elena.png"));
        products.add(new Product("ramses", "ramses.png"));
        return products;
    }
    
}

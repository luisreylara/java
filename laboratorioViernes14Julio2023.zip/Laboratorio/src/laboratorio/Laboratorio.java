 
package laboratorio;
 
import static laboratorio.ManejoArchivos.*;

public class Laboratorio {
 
    public static void main(String[] args) {
      //  crearArchivo2("si.txt");
        // escribirArchivo("academias.txt", "IFI");
       // anexarArchivo("academias.txt", "IRT");
       // anexarArchivo("academias", "IFI");
       // leerArchivo("universidades.txt");
        leerArchivoCSV("micsv.csv");
    }
    
}

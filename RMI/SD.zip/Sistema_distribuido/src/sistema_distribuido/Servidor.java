package sistema_distribuido;

import java.rmi.registry.Registry;
import javax.swing.JOptionPane;
 
public class Servidor {
    public static void main(String[] args) {
        try {
            //1099
            Registry r = java.rmi.registry.LocateRegistry.createRegistry(1100);
            System.setProperty("java.rmi.server.hostname","localhost");

            r.rebind("Calculadora", new rmi());
            System.out.println("Servidor conectado");
        } catch (Exception e) {
            System.out.println("Servidor no conectado :"+ e);
        }
    }
}

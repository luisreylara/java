
package sistema_distribuido;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Calculadora extends Remote{
     public int add(int a, int b)throws RemoteException;
     
}


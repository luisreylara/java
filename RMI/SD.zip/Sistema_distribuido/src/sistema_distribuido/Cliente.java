
package sistema_distribuido;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


import java.util.Scanner;
import javax.swing.JOptionPane;

public class Cliente {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            Registry miRegistro = LocateRegistry.getRegistry("localhost",1100);
            System.setProperty("java.rmi.server.hostname","localhost");
            Calculadora c = (Calculadora) miRegistro.lookup("Calculadora");
            String menu="";
            while (!menu.equals("5") ) {
                menu = JOptionPane.showInputDialog("ingrese: \n"+
                        "1.- Suma\n"+
                        "5.- Salir"
                        );
                switch (menu) {
                    case "1" :{
                        int x= Integer.parseInt(JOptionPane.showInputDialog("num1 :"));
                        int y= Integer.parseInt(JOptionPane.showInputDialog("num2 :"));
                        JOptionPane.showMessageDialog(null,"Suma :"+c.add(x,y));
                        break;
                    }
                    default:
                      //  throw new AssertionError();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "servidor no conectado "+e);
        }
    }
}

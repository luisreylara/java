package sistema_distribuido;


 public class Sistema_distribuido{}


        
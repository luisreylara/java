 
package servidorrmi;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
 
 
public class ServidorImpl extends UnicastRemoteObject implements ServidorRMI{
    
    private static ArrayList<Persona> listPersonas(){
        
        ArrayList<Persona> lista = new ArrayList<Persona>();
        lista.add(new Persona(1,"Luis Lara","luis@xxx.com","PTC",1000));
        lista.add(new Persona(2,"Hugo","hugo@xxx.com","PA",2000));
        lista.add(new Persona(3,"Paco Lara","paco@xxx.com","ADM",3000));
    
        return lista;
    }

    private static String getPersona(int id){
        return "Nombre: "+listPersonas().get(id-1).getNombre()+"\n"
               + "Email: "+listPersonas().get(id-1).getCorreo()+"\n"
               + "Cargo: "+listPersonas().get(id-1).getCargo()+"\n"
               + "Sueldo: "+listPersonas().get(id-1).getSueldo()
                ;
    }

    public ServidorImpl() throws RemoteException {
        super();
    }

    @Override
    public String consultar(int id) throws Exception {
        if(id<listPersonas().size()-1){
            return getPersona(id);
        }else{
            //return "No existen datos: "+listPersonas().size()+" id: "+id;
            return getPersona(id);
        }
            
    }
    public static void main(String[] args) throws RemoteException, Exception {
        ServidorImpl ser;
        
            ser = new ServidorImpl();
            System.out.println( ser.consultar(1));
            System.out.println( ser.consultar(2));
            System.out.println( ser.consultar(3));

    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package servidorrmi;
import java.rmi.Remote;
/**
 *
 * @author 52461
 */
public interface ServidorRMI extends Remote{
    public String consultar(int id) throws Exception;
}
